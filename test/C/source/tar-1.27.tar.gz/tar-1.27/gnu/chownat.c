/* -*- buffer-read-only: t -*- vi: set ro: */
/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
#include <config.h>
#define FCHOWNAT_INLINE _GL_EXTERN_INLINE
#include "openat.h"
